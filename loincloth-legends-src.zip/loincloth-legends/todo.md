# todo.md

## Pågår
- [ ] Få koden opp på GitHub: koble repoet til økten (så pusher Claude grenen `claude/loincloth-legends-v0.3`), eller push selv fra zip-filen
- [ ] Spilltesting med ekte mennesker: balanse på Gorthak (runde 2 og 3 kan være harde), fiendeskade, antall bølger, priser i butikken og XP-kurven

## Neste
- [ ] Balansetest av sjefene med ekte spillere (HP, skade, nedkjøling)
- [ ] Balansetest av ridedyr (stormløpet kan være for sterkt) og kjæledyr (Tiny Dragon og Rabid Rat)
- [ ] Test på ekte telefoner og nettbrett (iOS Safari og Android Chrome): berøringskontroller, lyd etter første trykk, ytelse
- [ ] Test med ekte gamepads (Xbox, PlayStation, Switch Pro, 8BitDo): knappeoppsett og rumble
- [ ] Henrettelser: spesial + angrep på en svimmel fiende med lite HP gir et eget dødsstøt per våpen
- [ ] Publikumsgunst i duellene (hån og stilige drap fyller en måler)
- [ ] Endeløs arena med lokal toppliste
- [ ] Hemmeligheter: gnomekonge, The Ham Dimension, bard som synger om drapene
- [ ] Co-op-gjenoppliving
- [ ] Koble inn heltebygger-lag som PNG (hår, hjelm, skjegg osv., se ART_PROMPTS.md "Planlagt")
- [ ] PNG for ridedyr, kjæledyr og farer (prompter ligger i ART_PROMPTS.md)
- [ ] Rekvisitter og ikoner som PNG
- [ ] Vis tittelbilde og sjef-VS-kort fra assets
- [ ] Rydd opp geometri/materialer når scener byttes (liten minnelekkasje ved mange omstarter)
- [ ] Slå sammen statisk miljø-geometri (palisaden) for færre draw calls
- [ ] Taleboblene og kunngjøringer bruker sanntid, ikke spilltid (merkes bare i slowmo)
- [ ] Flere kroppstyper i heltebyggeren (dverg, halvtroll, sint gnome)
- [ ] Opptil 4 spillere lokalt
- [ ] Tastebinding og CRT-filter i innstillingene
- [ ] Del opp JS-bunten (Three.js i egen chunk) hvis lastetiden blir et problem
- [ ] GitHub Actions: typecheck og bygg på hver push

## Ferdig
- [x] Vertikal slice: brett 1 + duell + menyer (2026-09-29)
- [x] 8 prosedyretegnede figurer med cutout-rigg
- [x] Gore-system med lemlestelse, gibs, fontener og blodflekker
- [x] Barbarian-duell med halshugging og CPU-AI
- [x] 2 spillere lokalt (co-op + PvP i gropa)
- [x] Syntetisert lyd og musikk
- [x] Single-file bygg og Artifact-eksport
- [x] Modulær, datadrevet arkitektur (2026-09-29)
- [x] Verdenskart med 10 noder og lagring
- [x] Fem biomer og fem brett
- [x] Fire sjefer med egen AI
- [x] Duell som finale og valgfrie arena-dueller, tag team
- [x] Hero Forge med opplåsbare deler
- [x] PNG-laster og grafikkliste til ChatGPT
- [x] Duell-modus bruker heltene fra Hero Forge i stedet for fast Thrugg
- [x] Playwright-tester oppdatert til v0.2 (story, scenarios, ai)
- [x] Overdrevne proporsjoner: stort hode, altfor store muskler, bittesmå lendeklær (v0.3, 2026-09-29)
- [x] Teit vold: impen sparker hodet i skjermen, armer ryker av (JUST A FLESH WOUND), hodeløse fiender løper rundt
- [x] Grep og kast, bowling og miljødrap
- [x] Farer i brettene: piggrop, myr, råk, lava, piggfelle
- [x] Ridedyr (War Hog, Cluckatrice, Magma Newt) og fiender som kommer ridende
- [x] Gore-innstilling og innstillingsmeny (gore, lyd, risting, rumble, berøring, fullskjerm)
- [x] Butikk (YE OLDE SHOPPE), XP, nivåer og STR/DEF/MAG/AGI
- [x] Fem kjæledyr
- [x] Berøringskontroller på mobil og nettbrett
- [x] Gamepad med standard mapping og rumble
- [x] Oppstartslogo for Tom's Happy Happy Funtimes Emporium
- [x] Playwright-tester for alt det nye (lineup, closeup, violence, grab, mounts, mountride, progress, pets, mobile, gamepad, splash, settings)
- [x] Klargjort for GitHub (.gitignore, AGENTS.md, CLAUDE.md, versjon 0.3.0, commit klar)
